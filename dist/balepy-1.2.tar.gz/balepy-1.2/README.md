# balepy

<h3 align="center"> balepy a Library Python for create bot API in bale application </h3>

> ## Install and Update:
```python
pip install -U balepy
```

## For See Docs:
### <a href="https://balepy.github.io">WebSite</a>
### <a href="https://t.me/TheCommit">TELEGRAM</a>

> ## START:
```python
from balepy import Client
from asyncio import run

bot = Client("TOKEN")

async def main():
    await bot.send_message(91837181, "Hello World")

run(main())
```

> ## Social Media:
#### <a href="https://t.me/TheCommit">TELEGRAM</a>
#### <a href="https://rubika.ir/TheBalepy">RUBIKA</a>
